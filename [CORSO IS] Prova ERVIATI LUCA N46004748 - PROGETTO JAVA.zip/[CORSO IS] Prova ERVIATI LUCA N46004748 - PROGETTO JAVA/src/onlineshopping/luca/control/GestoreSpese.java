package onlineshopping.luca.control;

import java.util.ArrayList;
import onlineshopping.luca.enity.*;

public class GestoreSpese {
	
	private ArrayList<Prodotto> prodottiInNegozio = new ArrayList<Prodotto>();
	private ArrayList<Cliente> clientiInNegozio = new ArrayList<Cliente>();
	private ArrayList<Spesa> listaSpese = new ArrayList<Spesa>();
	private ArrayList<Cliente> listaReport = new ArrayList<Cliente>();
	private int NumeroSpeseCliente;
	
	
	public GestoreSpese() {

		prodottiInNegozio.add(new Prodotto("Lavapavimenti Blu", "Lavapavimenti 1 litro concentrato 15%", 4, 20)); // 0
		prodottiInNegozio.add(new Prodotto("Lavapavimenti Rosso", "Lavapavimenti 1 litro concentrato 20%", 5, 20));// 1
		prodottiInNegozio.add(new Prodotto("Shampoo Antiforfora", "Shampoo 500 ml", 3, 15)); // 2
		prodottiInNegozio.add(new Prodotto("Shampoo Ricci", "Shampoo 500 ml", 2, 15)); // 3
		prodottiInNegozio.add(new Prodotto("Shampoo Lisci", "Shampoo 500 ml", 2, 15)); // 4
		prodottiInNegozio.add(new Prodotto("Dopobarba Delicato", "Liquido 100 ml", 7, 10)); // 5

	}

	
	public void aggiungiSpesa(Spesa s) {
		
		listaSpese.add(s);														// aggiungi la spesa alla lista delle spese
		s.getClienteSpesa().setNumeroSpese();									// incrementa numero spese del cliente che ha effettuato la spesa
		s.getClienteSpesa().setImportoSpesoComplessivo(s.CalcolaCostoTotale());	// somma l'importo di tutte le spese effettuate
	
	}

	public void ottieniNumeroSpese(ArrayList<Cliente> clientiInNegozio) {

		for (Cliente cl : clientiInNegozio) {
			System.out.println("Cliente: " + cl.getNome() + ", numero spese: " + cl.getNumeroSpese()
					+ ", importo speso complessivamente: " + cl.getImportoSpesoComplessivo() + " euro");
		}
	}

	public void visualizzaScontrino(ArrayList<Spesa> listaSpese) {
		for (Spesa s : listaSpese) {
			System.out.println("Spesa n." + s.getID() + ", Cliente: " + s.getClienteSpesa().getNome()
					+ ", Totale conto: " + s.CalcolaCostoTotale() + "€");
		}
	}
	
	
	//Crea Lista con tutti i clienti per il Report che hanno effettuato NumeroSpeseCliente spese
	public ArrayList<Cliente> creaReport(ArrayList<Cliente> clientiInNegozio, int NumeroSpeseCliente) {
		if (NumeroSpeseCliente > 0) {
			if (clientiInNegozio.isEmpty() == false) {
				setNumeroSpeseCliente(NumeroSpeseCliente);
				for (Cliente cl : clientiInNegozio) {
					if (cl.getNumeroSpese() >= NumeroSpeseCliente) {
						listaReport.add(cl);
					}
				}
				if (listaReport.isEmpty() == true && NumeroSpeseCliente > 0) {
					System.out.println("-- NESSUN REPORT DISPONIBILE -- NESSUN CLIENTE CON ALMENO "
							+ getNumeroSpeseCliente() + " SPESE");
				}
			} else {
				System.out.println("-- ERRORE -- NON SONO PRESENTI UTENTI REGISTRATI NEL SISTEMA");
			}
		} else {
			System.out.println("-- ERRORE -- INSERIRE UN VALORE NUMEROSPESECLIENTE MAGGIORE DI ZERO");
		}
		return listaReport;

	}
	
	
	//Stampa lista report
	public void stampaReport(ArrayList<Cliente> listaReport) {
		if (listaReport.isEmpty() == false) {
			System.out.println("REPORT CLIENTI ABITUALI CON ALMENO " + getNumeroSpeseCliente() + " SPESE");
			for (Cliente cl : listaReport) {
				System.out.println("Cliente: " + cl.getNome() + ", Numero spese: " + cl.getNumeroSpese()
						+ ", Importo speso complessivamente: " + cl.getImportoSpesoComplessivo() + " euro");
			}
		}
	}
	
	

	public ArrayList<Prodotto> getProdottiInNegozio() {
		return prodottiInNegozio;
	}

	public void setProdottiInNegozio(ArrayList<Prodotto> prodottiInNegozio) {
		this.prodottiInNegozio = prodottiInNegozio;
	}

	public ArrayList<Spesa> getListaSpese() {
		return listaSpese;
	}

	public void setListaSpese(ArrayList<Spesa> listaSpese) {
		this.listaSpese = listaSpese;
	}

	public ArrayList<Cliente> getClientiInNegozio() {
		return clientiInNegozio;
	}

	public void setClientiInNegozio(ArrayList<Cliente> clientiInNegozio) {
		this.clientiInNegozio = clientiInNegozio;
	}

	public int getNumeroSpeseCliente() {
		return NumeroSpeseCliente;
	}

	public void setNumeroSpeseCliente(int numeroSpeseCliente) {
		NumeroSpeseCliente = numeroSpeseCliente;
	}

	public ArrayList<Cliente> getListaReport() {
		return listaReport;
	}

	public void setListaReport(ArrayList<Cliente> listaReport) {
		this.listaReport = listaReport;
	}
	
	
	
	

}
