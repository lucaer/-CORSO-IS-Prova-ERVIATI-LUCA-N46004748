package onlineshopping.luca.enity;

public class Cliente {
	private String Nome;
	private String Password;
	private int Telefono;
	private int CartaDiCredito;
	private int NumeroSpese;
	private int ImportoSpesoComplessivo;
	
	//costruttore
	public Cliente(String nome, String password, int telefono, int cartaDiCredito) {
		super();
		Nome = nome;
		Password = password;
		Telefono = telefono;
		CartaDiCredito = cartaDiCredito;
	}

	//metodi get e set
	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public int getTelefono() {
		return Telefono;
	}

	public void setTelefono(int telefono) {
		Telefono = telefono;
	}

	public int getCartaDiCredito() {
		return CartaDiCredito;
	}

	public void setCartaDiCredito(int cartaDiCredito) {
		CartaDiCredito = cartaDiCredito;
	}

	public int getNumeroSpese() {
		return NumeroSpese;
	}
	
	public void setNumeroSpese() {
		NumeroSpese +=1;
	}
	
	public int getImportoSpesoComplessivo() {
		return ImportoSpesoComplessivo;
	}

	public void setImportoSpesoComplessivo(int Importo) {
		ImportoSpesoComplessivo += Importo;
	}
	
	public String toString() {
		return "Cliente [Nome=" + Nome + ", Password=" + Password + ", Telefono=" + Telefono + ", CartaDiCredito="
				+ CartaDiCredito + ", NumeroSpese=" + NumeroSpese + "]";
	}


	
	
	
	

}
