package onlineshopping.luca.enity;

public enum Stato {
	ORDINATA,
	CONSEGNATA;

}
