package onlineshopping.luca.enity;


public class CarrelloProdotti {
	
	private int quantità;
	private Prodotto prodotto;
	
	//costruttore
	public CarrelloProdotti(int quantità, Prodotto prodotto) {
		this.quantità = quantità;
		this.prodotto = prodotto;
	}

	//metodi get e set
	public int getQuantità() {
		return quantità;
	}

	public void setQuantità(int quantità) {
		this.quantità = quantità;
	}

	public Prodotto getProdotto() {
		return prodotto;
	}

	public void setProdotto(Prodotto prodotto) {
		this.prodotto = prodotto;
	}
	
	public String toString() {
		return "CarrelloProdotti [quantità=" + quantità + ", prodotto=" + prodotto + "]";
	}
	
	

}
