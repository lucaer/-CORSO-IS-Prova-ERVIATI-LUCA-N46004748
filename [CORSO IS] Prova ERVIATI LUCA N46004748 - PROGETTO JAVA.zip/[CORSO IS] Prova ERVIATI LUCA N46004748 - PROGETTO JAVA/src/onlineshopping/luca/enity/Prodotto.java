package onlineshopping.luca.enity;

public class Prodotto {
	
	private int Codice;
	private String Nome;
	private String Descrizione;
	private int Prezzo;
	private int QuantitàDisponibile;
	
	//costruttori
	public Prodotto(int codice, String nome, String descrizione, int prezzo, int quantitàDisponibile) {
		this.setCodice(codice);
		this.Nome = nome;
		this.Descrizione = descrizione;
		this.Prezzo = prezzo;
		this.QuantitàDisponibile = quantitàDisponibile;
	}
	
	public Prodotto(String nome, String descrizione, int prezzo, int quantitàDisponibile) {
		this.setCodice(-1);
		this.Nome = nome;
		this.Descrizione = descrizione;
		this.Prezzo = prezzo;
		this.QuantitàDisponibile = quantitàDisponibile;
	}

	//metodo to string
	public String toString() {
		return "Prodotto [Codice=" + Codice + ", Nome=" + Nome + ", Descrizione=" + Descrizione + ", Prezzo=" + Prezzo
				+ ", QuantitàDisponibile=" + QuantitàDisponibile + "]";
	}

	//metodi get e set
	public int getCodice() {
		return Codice;
	}

	public void setCodice(int codice) {
		Codice = codice;
	}

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getDescrizione() {
		return Descrizione;
	}

	public void setDescrizione(String descrizione) {
		Descrizione = descrizione;
	}

	public int getPrezzo() {
		return Prezzo;
	}

	public void setPrezzo(int prezzo) {
		Prezzo = prezzo;
	}

	public int getQuantitàDisponibile() {
		return QuantitàDisponibile;
	}

	public void setQuantitàDisponibile(int quantitàDisponibile) {
		QuantitàDisponibile = quantitàDisponibile;
	}
	
	
	
	
	
	

}
