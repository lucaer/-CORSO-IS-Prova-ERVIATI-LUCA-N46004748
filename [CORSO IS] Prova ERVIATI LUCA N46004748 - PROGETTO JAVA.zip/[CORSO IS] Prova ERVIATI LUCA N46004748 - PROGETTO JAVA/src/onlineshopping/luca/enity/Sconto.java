package onlineshopping.luca.enity;

import java.time.LocalDate;

public class Sconto {
	
	private int CodiceSconto;
	private int PercentualeSconto;
	private LocalDate DataScadenza;
	private boolean Usato;
	
	//costruttore
	public Sconto(int codiceSconto, int percentualeSconto, LocalDate dataScadenza, boolean usato) {
		this.CodiceSconto = codiceSconto;
		this.PercentualeSconto = percentualeSconto;
		this.DataScadenza = dataScadenza;
		this.Usato = usato;
	}

	//metodi get e set
	public int getCodiceSconto() {
		return CodiceSconto;
	}

	public void setCodiceSconto(int codiceSconto) {
		CodiceSconto = codiceSconto;
	}

	public int getPercentualeSconto() {
		return PercentualeSconto;
	}

	public void setPercentualeSconto(int percentualeSconto) {
		PercentualeSconto = percentualeSconto;
	}

	public LocalDate getDataScadenza() {
		return DataScadenza;
	}

	public void setDataScadenza(LocalDate dataScadenza) {
		DataScadenza = dataScadenza;
	}

	public boolean isUsato() {
		return Usato;
	}

	public void setUsato(boolean usato) {
		Usato = usato;
	}
	
	
	
	

}
