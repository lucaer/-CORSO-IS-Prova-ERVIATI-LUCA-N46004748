package onlineshopping.luca.enity;

import java.time.LocalDate;
import java.util.ArrayList;


public class Spesa {
	
	private static int SpesaCounter = 0;
	private int ID;
	private LocalDate Data;
	private int CostoTotale;
	private Stato StatoSpesa;
	private Cliente ClienteSpesa;
	private Sconto ScontoSpesa;
	
	private ArrayList<CarrelloProdotti> cart_prodotti = new ArrayList<CarrelloProdotti>();
	
	public Spesa(Prodotto[] prodotti, int [] qtaProdotti, Cliente c) {

		this.ID = ++SpesaCounter;
		
		int i;
		
		for(i=0; i<prodotti.length; i++) {
			cart_prodotti.add(new CarrelloProdotti(qtaProdotti[i], prodotti[i]));
		}
		
		setClienteSpesa(c);
		
	}

	//metodi get e set
	public static int getSpesaCounter() {
		return SpesaCounter;
	}

	public static void setSpesaCounter(int spesaCounter) {
		SpesaCounter = spesaCounter;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public LocalDate getData() {
		return Data;
	}

	public void setData(LocalDate data) {
		Data = data;
	}

	public int getCostoTotale() {
		return CostoTotale;
	}

	public void setCostoTotale(int costoTotale) {
		CostoTotale = costoTotale;
	}

	public Cliente getClienteSpesa() {
		return ClienteSpesa;
	}

	public void setClienteSpesa(Cliente clienteSpesa) {
		ClienteSpesa = clienteSpesa;
	}

	public ArrayList<CarrelloProdotti> getCart_prodotti() {
		return cart_prodotti;
	}

	public void setCart_prodotti(ArrayList<CarrelloProdotti> cart_prodotti) {
		this.cart_prodotti = cart_prodotti;
	}

	public Stato getStatoSpesa() {
		return StatoSpesa;
	}

	public void setStatoSpesa(Stato statoSpesa) {
		StatoSpesa = statoSpesa;
	}

	public Sconto getScontoSpesa() {
		return ScontoSpesa;
	}

	public void setScontoSpesa(Sconto scontoSpesa) {
		ScontoSpesa = scontoSpesa;
	}
	
	public int CalcolaCostoTotale() {
		
		int CostoTotale=0;
		
		for(CarrelloProdotti c: cart_prodotti) {
				int Prezzo = c.getProdotto().getPrezzo();
				Prezzo = Prezzo * c.getQuantità();
				CostoTotale += Prezzo;
		}
		
		return CostoTotale;
	}

	public String toString() {
		return "Spesa [ID=" + ID + ", Data=" + Data + ", CostoTotale=" + CostoTotale + ", StatoSpesa=" + StatoSpesa
				+ ", ClienteSpesa=" + ClienteSpesa + ", ScontoSpesa=" + ScontoSpesa + ", cart_prodotti=" + cart_prodotti
				+ "]";
	}
	
	
	
	

}
