package test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import onlineshopping.luca.control.*;
import onlineshopping.luca.enity.*;

import org.junit.After;
import org.junit.Test;

public class GeneraReportTest {
	
	GestoreSpese gestoreSpese =  new GestoreSpese();
	ArrayList<Prodotto> prodottiInNegozio = gestoreSpese.getProdottiInNegozio();
	ArrayList<Cliente> clientiInNegozio = gestoreSpese.getClientiInNegozio();
	ArrayList<Spesa> listaSpese = gestoreSpese.getListaSpese();
	ArrayList<Cliente> listaReport = gestoreSpese.getListaReport();
	int [] qtaProdotti;
	
	
	@After
	public void tearDown() {
		System.out.println("\n\n");
	}
	

	@Test
	public void test01NumeroSpeseClienteNegativo() {
		System.out.println(" TEST 01 ");
		gestoreSpese.creaReport(clientiInNegozio, -4);
		assertTrue(listaReport.isEmpty());
	}
	
	@Test
	public void test02NessunUtenteRegistrato() {
		System.out.println(" TEST 02 ");
		gestoreSpese.creaReport(clientiInNegozio, 2);
		assertTrue(listaReport.isEmpty());
	}
	
	@Test
	public void test03UtentiPresentiNumeroSpeseClienteNegativo() {
		System.out.println(" TEST 03 ");
		clientiInNegozio.add( new Cliente("MARIO", "MARIO001", 223333, 223445));									//0
		clientiInNegozio.add( new Cliente("LUCA", "LUCA123", 113333, 222345));										//1
		clientiInNegozio.add( new Cliente("ANNA", "ANNA111", 223344, 221211));										//2
		gestoreSpese.creaReport(clientiInNegozio, -2);
		assertTrue(listaReport.isEmpty());
	}
	
	@Test
	public void test04UtentiPresentiNessunaSpesaPresente() {
		System.out.println(" TEST 04 ");
		clientiInNegozio.add( new Cliente("MARIO", "MARIO001", 223333, 223445));									//0
		clientiInNegozio.add( new Cliente("LUCA", "LUCA123", 113333, 222345));										//1
		clientiInNegozio.add( new Cliente("ANNA", "ANNA111", 223344, 221211));										//2
		gestoreSpese.creaReport(clientiInNegozio, 3);
		assertTrue(listaReport.isEmpty());
	}
	
	@Test
	public void test05UtentiPresentiSpesePresentiNumeroSpeseClienteNegativo() {
		System.out.println(" TEST 05 ");
		clientiInNegozio.add( new Cliente("MARIO", "MARIO001", 223333, 223445));									//0
		clientiInNegozio.add( new Cliente("LUCA", "LUCA123", 113333, 222345));										//1
		clientiInNegozio.add( new Cliente("ANNA", "ANNA111", 223344, 221211));										//2
		
		//Spesa 1
		Prodotto [] prodotti = new Prodotto[3];
		prodotti[0] = prodottiInNegozio.get(1); 			// Lavapavimenti 1 litro concentrato 20%, 5 euro
		prodotti[1] = prodottiInNegozio.get(2); 			// Antiforfora Shampoo 500 ml, 3 euro
		prodotti[2] = prodottiInNegozio.get(3); 			// Ricci Shampoo 500 ml, 2 euro
		qtaProdotti = new int [] {1, 2, 2};
		Cliente c = clientiInNegozio.get(1);				// Cliente: LUCA
		Spesa s1 = new Spesa(prodotti, qtaProdotti, c);
				
				
		//Spesa 2
		prodotti = new Prodotto[3];
		prodotti[0] = prodottiInNegozio.get(1); 			// Lavapavimenti 1 litro concentrato 20%, 5 euro
		prodotti[1] = prodottiInNegozio.get(2); 			// Antiforfora Shampoo 500 ml, 3 euro
		prodotti[2] = prodottiInNegozio.get(3); 			// Ricci Shampoo 500 ml, 2 euro
		qtaProdotti = new int[] { 1, 1, 1 };
		c = clientiInNegozio.get(1);						// Cliente: LUCA
		Spesa s2 = new Spesa(prodotti, qtaProdotti, c);
		
		gestoreSpese.aggiungiSpesa(s1);
		gestoreSpese.aggiungiSpesa(s2);
				
		gestoreSpese.creaReport(clientiInNegozio, -1);
		assertTrue(listaReport.isEmpty());
	}
	
	@Test
	public void test06UtentiSpesePresentiNumeroSpeseClienteTroppoAlto() {
		System.out.println(" TEST 06 ");
		clientiInNegozio.add( new Cliente("MARIO", "MARIO001", 223333, 223445));									//0
		clientiInNegozio.add( new Cliente("LUCA", "LUCA123", 113333, 222345));										//1
		clientiInNegozio.add( new Cliente("ANNA", "ANNA111", 223344, 221211));										//2
		
		//Spesa 1
		Prodotto [] prodotti = new Prodotto[3];
		prodotti[0] = prodottiInNegozio.get(1); 			// Lavapavimenti 1 litro concentrato 20%, 5 euro
		prodotti[1] = prodottiInNegozio.get(2); 			// Antiforfora Shampoo 500 ml, 3 euro
		prodotti[2] = prodottiInNegozio.get(3); 			// Ricci Shampoo 500 ml, 2 euro
		qtaProdotti = new int [] {1, 2, 2};
		Cliente c = clientiInNegozio.get(1);				// Cliente: LUCA
		Spesa s1 = new Spesa(prodotti, qtaProdotti, c);
				
				
		//Spesa 2
		prodotti = new Prodotto[3];
		prodotti[0] = prodottiInNegozio.get(1); 			// Lavapavimenti 1 litro concentrato 20%, 5 euro
		prodotti[1] = prodottiInNegozio.get(2); 			// Antiforfora Shampoo 500 ml, 3 euro
		prodotti[2] = prodottiInNegozio.get(3); 			// Ricci Shampoo 500 ml, 2 euro
		qtaProdotti = new int[] { 1, 1, 1 };
		c = clientiInNegozio.get(1);						// Cliente: LUCA
		Spesa s2 = new Spesa(prodotti, qtaProdotti, c);
		
		gestoreSpese.aggiungiSpesa(s1);
		gestoreSpese.aggiungiSpesa(s2);
				
		gestoreSpese.creaReport(clientiInNegozio, 5);
		assertTrue(listaReport.isEmpty());
	}
	
	@Test
	public void test07UtentiSpesePresentiNumeroSpeseClienteUnico() {
		System.out.println(" TEST 07 ");
		clientiInNegozio.add( new Cliente("MARIO", "MARIO001", 223333, 223445));									//0
		clientiInNegozio.add( new Cliente("LUCA", "LUCA123", 113333, 222345));										//1
		clientiInNegozio.add( new Cliente("ANNA", "ANNA111", 223344, 221211));										//2
		
		//Spesa 1
		Prodotto [] prodotti = new Prodotto[3];
		prodotti[0] = prodottiInNegozio.get(1); 			// Lavapavimenti 1 litro concentrato 20%, 5 euro
		prodotti[1] = prodottiInNegozio.get(2); 			// Antiforfora Shampoo 500 ml, 3 euro
		prodotti[2] = prodottiInNegozio.get(3); 			// Ricci Shampoo 500 ml, 2 euro
		qtaProdotti = new int [] {1, 2, 2};
		Cliente c = clientiInNegozio.get(1);				// Cliente: LUCA
		Spesa s1 = new Spesa(prodotti, qtaProdotti, c);
				
				
		//Spesa 2
		prodotti = new Prodotto[3];
		prodotti[0] = prodottiInNegozio.get(1); 			// Lavapavimenti 1 litro concentrato 20%, 5 euro
		prodotti[1] = prodottiInNegozio.get(2); 			// Antiforfora Shampoo 500 ml, 3 euro
		prodotti[2] = prodottiInNegozio.get(3); 			// Ricci Shampoo 500 ml, 2 euro
		qtaProdotti = new int[] { 1, 1, 1 };
		c = clientiInNegozio.get(1);						// Cliente: LUCA
		Spesa s2 = new Spesa(prodotti, qtaProdotti, c);
		
		gestoreSpese.aggiungiSpesa(s1);
		gestoreSpese.aggiungiSpesa(s2);
				
		gestoreSpese.creaReport(clientiInNegozio, 2);
		assertEquals(1, listaReport.size());
		assertEquals("LUCA", listaReport.get(0).getNome());
		
		gestoreSpese.stampaReport(listaReport);
	}
	
	@Test
	public void test08UtentiSpesePresentiNumeroSpeseClienteUnico() {
		System.out.println(" TEST 08 ");
		clientiInNegozio.add( new Cliente("MARIO", "MARIO001", 223333, 223445));									//0
		clientiInNegozio.add( new Cliente("LUCA", "LUCA123", 113333, 222345));										//1
		clientiInNegozio.add( new Cliente("ANNA", "ANNA111", 223344, 221211));										//2
		
		// Spesa 1
		Prodotto[] prodotti = new Prodotto[3];
		prodotti[0] = prodottiInNegozio.get(1); // Lavapavimenti 1 litro concentrato 20%, 5 euro
		prodotti[1] = prodottiInNegozio.get(2); // Antiforfora Shampoo 500 ml, 3 euro
		prodotti[2] = prodottiInNegozio.get(3); // Ricci Shampoo 500 ml, 2 euro
		qtaProdotti = new int[] { 1, 2, 2 };
		Cliente c = clientiInNegozio.get(2); // Cliente: ANNA
		Spesa s1 = new Spesa(prodotti, qtaProdotti, c);

		// Spesa 2
		prodotti = new Prodotto[3];
		prodotti[0] = prodottiInNegozio.get(1); // Lavapavimenti 1 litro concentrato 20%, 5 euro
		prodotti[1] = prodottiInNegozio.get(2); // Antiforfora Shampoo 500 ml, 3 euro
		prodotti[2] = prodottiInNegozio.get(3); // Ricci Shampoo 500 ml, 2 euro
		qtaProdotti = new int[] { 1, 1, 1 };
		c = clientiInNegozio.get(1); // Cliente: LUCA
		Spesa s2 = new Spesa(prodotti, qtaProdotti, c);

		// Spesa 3
		prodotti = new Prodotto[2];
		prodotti[0] = prodottiInNegozio.get(0); // Lavapavimenti 1 litro concentrato 15%, 4 euro
		prodotti[1] = prodottiInNegozio.get(5); // Dopobarba Delicato, 7 euro
		qtaProdotti = new int[] { 2, 2 };
		c = clientiInNegozio.get(2); // Cliente: ANNA
		Spesa s3 = new Spesa(prodotti, qtaProdotti, c);

		// Spesa 4
		prodotti = new Prodotto[3];
		prodotti[0] = prodottiInNegozio.get(0); // Lavapavimenti 1 litro concentrato 15%, 4 euro
		prodotti[1] = prodottiInNegozio.get(4); // Lisci Shampoo 500 ml, 2 euro
		prodotti[2] = prodottiInNegozio.get(3); // Antiforfora Shampoo 500 ml, 2 euro
		qtaProdotti = new int[] { 2, 2, 2 };
		c = clientiInNegozio.get(1); // Cliente: LUCA
		Spesa s4 = new Spesa(prodotti, qtaProdotti, c);
				
		
		gestoreSpese.aggiungiSpesa(s1);
		gestoreSpese.aggiungiSpesa(s2);
		gestoreSpese.aggiungiSpesa(s3);
		gestoreSpese.aggiungiSpesa(s4);
				
		gestoreSpese.creaReport(clientiInNegozio, 2);
		assertEquals(2, listaReport.size());
		assertEquals("LUCA", listaReport.get(0).getNome());
		assertEquals("ANNA", listaReport.get(1).getNome());
		gestoreSpese.stampaReport(listaReport);
	}
	
	@Test
	public void test09UtentiSpesePresentiNumeroSpeseClienteDiversi() {
		System.out.println(" TEST 09 ");
		clientiInNegozio.add( new Cliente("MARIO", "MARIO001", 223333, 223445));									//0
		clientiInNegozio.add( new Cliente("LUCA", "LUCA123", 113333, 222345));										//1
		clientiInNegozio.add( new Cliente("ANNA", "ANNA111", 223344, 221211));										//2
		
		// Spesa 1
		Prodotto[] prodotti = new Prodotto[3];
		prodotti[0] = prodottiInNegozio.get(1); // Lavapavimenti 1 litro concentrato 20%, 5 euro
		prodotti[1] = prodottiInNegozio.get(2); // Antiforfora Shampoo 500 ml, 3 euro
		prodotti[2] = prodottiInNegozio.get(3); // Ricci Shampoo 500 ml, 2 euro
		qtaProdotti = new int[] { 1, 2, 2 };
		Cliente c = clientiInNegozio.get(2); // Cliente: ANNA
		Spesa s1 = new Spesa(prodotti, qtaProdotti, c);

		// Spesa 2
		prodotti = new Prodotto[3];
		prodotti[0] = prodottiInNegozio.get(1); // Lavapavimenti 1 litro concentrato 20%, 5 euro
		prodotti[1] = prodottiInNegozio.get(2); // Antiforfora Shampoo 500 ml, 3 euro
		prodotti[2] = prodottiInNegozio.get(3); // Ricci Shampoo 500 ml, 2 euro
		qtaProdotti = new int[] { 1, 1, 1 };
		c = clientiInNegozio.get(1); // Cliente: LUCA
		Spesa s2 = new Spesa(prodotti, qtaProdotti, c);

		// Spesa 3
		prodotti = new Prodotto[2];
		prodotti[0] = prodottiInNegozio.get(0); // Lavapavimenti 1 litro concentrato 15%, 4 euro
		prodotti[1] = prodottiInNegozio.get(5); // Dopobarba Delicato, 7 euro
		qtaProdotti = new int[] { 2, 2 };
		c = clientiInNegozio.get(2); // Cliente: ANNA
		Spesa s3 = new Spesa(prodotti, qtaProdotti, c);

		// Spesa 4
		prodotti = new Prodotto[3];
		prodotti[0] = prodottiInNegozio.get(0); // Lavapavimenti 1 litro concentrato 15%, 4 euro
		prodotti[1] = prodottiInNegozio.get(4); // Lisci Shampoo 500 ml, 2 euro
		prodotti[2] = prodottiInNegozio.get(3); // Antiforfora Shampoo 500 ml, 2 euro
		qtaProdotti = new int[] { 2, 2, 2 };
		c = clientiInNegozio.get(1); // Cliente: LUCA
		Spesa s4 = new Spesa(prodotti, qtaProdotti, c);

		// Spesa 5
		prodotti = new Prodotto[4];
		prodotti[0] = prodottiInNegozio.get(0); // Lavapavimenti 1 litro concentrato 15%, 4 euro
		prodotti[1] = prodottiInNegozio.get(4); // Lisci Shampoo 500 ml, 2 euro
		prodotti[2] = prodottiInNegozio.get(3); // Antiforfora Shampoo 500 ml, 2 euro
		prodotti[3] = prodottiInNegozio.get(5); // Dopobarba Delicato, 7 euro
		qtaProdotti = new int[] { 2, 2, 2, 3 };
		c = clientiInNegozio.get(2); // Cliente: ANNA
		Spesa s5 = new Spesa(prodotti, qtaProdotti, c);

		// Spesa 6
		prodotti = new Prodotto[5];
		prodotti[0] = prodottiInNegozio.get(0); // Lavapavimenti 1 litro concentrato 15%, 4 euro
		prodotti[1] = prodottiInNegozio.get(4); // Lisci Shampoo 500 ml, 2 euro
		prodotti[2] = prodottiInNegozio.get(3); // Antiforfora Shampoo 500 ml, 2 euro
		prodotti[3] = prodottiInNegozio.get(5); // Dopobarba Delicato, 7 euro
		prodotti[4] = prodottiInNegozio.get(1); // Lavapavimenti Rosso, 5 euro
		qtaProdotti = new int[] { 1, 2, 2, 1, 1 };
		c = clientiInNegozio.get(0); // Cliente: MARIO
		Spesa s6 = new Spesa(prodotti, qtaProdotti, c);
				
		
		gestoreSpese.aggiungiSpesa(s1);
		gestoreSpese.aggiungiSpesa(s2);
		gestoreSpese.aggiungiSpesa(s3);
		gestoreSpese.aggiungiSpesa(s4);
		gestoreSpese.aggiungiSpesa(s5);
		gestoreSpese.aggiungiSpesa(s6);
				
		gestoreSpese.creaReport(clientiInNegozio, 2);
		assertEquals(2, listaReport.size());
		assertEquals("LUCA", listaReport.get(0).getNome());
		assertEquals("ANNA", listaReport.get(1).getNome());
		assertEquals(3, listaReport.get(1).getNumeroSpese());
		assertEquals(2, listaReport.get(0).getNumeroSpese());
		gestoreSpese.stampaReport(listaReport);
	}
	
	
	

}
